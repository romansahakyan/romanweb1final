<?php include_once("page1.html"); ?>
<?php include_once("page2.html"); ?>
